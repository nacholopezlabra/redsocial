import { Component, OnInit } from '@angular/core';
import { usuarios } from '../clases/usuarios';

@Component({
  selector: 'app-paneluser',
  templateUrl: './paneluser.component.html',
  styleUrls: ['./paneluser.component.css']
})
export class PaneluserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  user:usuarios = new usuarios();

}
