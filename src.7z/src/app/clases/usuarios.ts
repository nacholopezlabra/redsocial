export class usuarios {

nombreusuario:string ="";
apellidos: string="";
edad:number=0;
foto:string="";
descripcion:string="";
correo:string="";
contrasena:string="";
confirmarcontrasena:string="";

constructor(){}

}