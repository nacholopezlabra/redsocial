import { Component, OnInit } from '@angular/core';
import { usuarios } from '../clases/usuarios';
import { FormControl, FormGroup,Validators } from '@angular/forms';
import { BsModalService,BsModalRef } from 'ngx-bootstrap/modal';
import Swal from 'sweetalert2';
import { PaneluserComponent } from '../paneluser/paneluser.component';


@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})






export class RegistroComponent implements OnInit {
  
  constructor(private modalService:BsModalService) { }
  usuarioregistrado:usuarios= new usuarios(); 
  user:usuarios[]=[];

  validarusuario:FormGroup = new FormGroup({
    nombreusuario: new FormControl (''),
    apellidos: new FormControl (''),
    edad:new FormControl (''),
    foto:new FormControl (''),
    descripcion: new FormControl (''),
    correo: new FormControl (''),
    contrasena: new FormControl (''),
    confirmarcontrasena: new FormControl ('')
    
  });

 
onSubmit(){

  this.usuarioregistrado.nombreusuario = this.validarusuario.get('nombreusuario')?.value;
  this.usuarioregistrado.apellidos = this.validarusuario.get('apellidos')?.value;
  this.usuarioregistrado.edad = this.validarusuario.get('edad')?.value;
  this.usuarioregistrado.foto = this.validarusuario.get('foto')?.value;
  this.usuarioregistrado.descripcion = this.validarusuario.get('descripcion')?.value;
  this.usuarioregistrado.correo = this.validarusuario.get('correo')?.value;
  this.usuarioregistrado.contrasena = this.validarusuario.get('contrasena')?.value;
  this.usuarioregistrado.confirmarcontrasena = this.validarusuario.get('confirmarcontrasena')?.value;

}

  ngOnInit(): void {  
    this.validarusuario = new FormGroup({
    nombreusuario: new FormControl('',[Validators.required]),
      apellidos: new FormControl('', [Validators.required]),
      edad: new FormControl('', [Validators.required]),
      foto: new FormControl('', [Validators.required]),
      descripcion: new FormControl('', [Validators.required,Validators.minLength(2)]  ),
      correo:  new FormControl('', [Validators.required , Validators.email]),
      contrasena:new FormControl('', [Validators.required]),
      confirmarcontrasena:new FormControl('', [Validators.required])
      
  });
  }


  passwordMatchValidator() {
    
       
       console.log(this.validarusuario.get('contraseña'));
       let controlForm:boolean = true;
       if(!this.validarusuario.get('contraseña')?.value == this.validarusuario.get('confirmarcontraseña')?.value){
        controlForm = false;
        Swal.fire(
          'Error!',
          'Las contraseñas no coinciden!',
          'error'
        )
       }


       if(controlForm){
        this.user.push(this.usuarioregistrado);
  }
       }
subirfoto(event:any){
this.usuarioregistrado.foto="data: "+event.target.files[0].type+";base64 "+btoa(event.target.files[0].name)
}

 }







